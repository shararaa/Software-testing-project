package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.FileUpload;
import pages.HomePage;

public class FileUploadTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
	FileUpload fileUploadObject = new FileUpload(driver);
	
	@Test
	public void upload() {
		homePageObject.openFileUpload();
		fileUploadObject.uploadFile("C:\\Users\\mshar\\OneDrive\\Desktop\\test.bat");
		Assert.assertTrue(fileUploadObject.isUploaded());
	}
}
