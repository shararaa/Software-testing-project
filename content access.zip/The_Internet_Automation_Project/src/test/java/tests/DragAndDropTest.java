package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DragAndDrop;
import pages.HomePage;

public class DragAndDropTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
	DragAndDrop dragAndDropObject = new DragAndDrop(driver);
	
  @Test
  public void testDragAndDrop() {
	  
	  homePageObject.openDragAndDrop();
	  Assert.assertEquals(dragAndDropObject.source.getText(), "A");
	  Assert.assertEquals(dragAndDropObject.destination.getText(), "B");
	  
	  dragAndDropObject.switchPlaces();
	  
	  Assert.assertEquals(dragAndDropObject.source.getText(), "B");
	  Assert.assertEquals(dragAndDropObject.destination.getText(), "A");
  }
}
