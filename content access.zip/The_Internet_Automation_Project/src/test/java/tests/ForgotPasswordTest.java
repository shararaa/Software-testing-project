package tests;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ForgotPassword;
import pages.HomePage;

public class ForgotPasswordTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
	ForgotPassword forgotPasswordObject = new ForgotPassword(driver);
	
  @Test (priority = 1)
  public void PostiveScenario() throws InterruptedException {
	  homePageObject.openForgotPassword();
	  forgotPasswordObject.validEmail();
	  
	  WebElement body = driver.findElement(By.xpath("/html/body/h1"));
	  Assert.assertTrue(body.getText().equalsIgnoreCase("Email has been sent !"));
  }
  
  @Test (priority = 2)
  public void negativeScenario() {
	  driver.navigate().back();
	  forgotPasswordObject.nonValidEmail();
	  
	  WebElement body = driver.findElement(By.xpath("/html/body/h1"));
	  Assert.assertTrue(body.getText().equalsIgnoreCase("please enter an valid Email !"));
	  
	  driver.navigate().back();
  }
}
