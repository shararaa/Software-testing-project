package tests;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DropdownList;
import pages.HomePage;

public class DropdownListTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
	DropdownList dropdownListObject = new DropdownList(driver);
	
  @Test
  public void testDropdownList() {
	  homePageObject.openDropdownList();
	  
	  Select makeDropdown = new Select(dropdownListObject.list);
	  Assert.assertEquals(makeDropdown.getOptions().size(), 3);
	  Assert.assertFalse(makeDropdown.isMultiple());
	  
	  List <WebElement> options = makeDropdown.getOptions();
	  for (WebElement webElement : options) {
		System.out.println(webElement.getText());
	}
	  
	  makeDropdown.selectByIndex(1);
	  Assert.assertEquals(makeDropdown.getFirstSelectedOption().getText(),"Option 1");
	  
	  makeDropdown.selectByVisibleText("Option 2");
	  Assert.assertEquals("Option 2", makeDropdown.getFirstSelectedOption().getText());
	  
	  makeDropdown.selectByValue("1");
	  Assert.assertEquals("Option 1", makeDropdown.getFirstSelectedOption().getText());
  }
}
