package tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;

public class TablesTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
//	Tables tablesObject = new Tables(driver);
//	
//  @Test
//  public void table1Test() {
//	  homePageObject.openTables();
//  	  Assert.assertEquals(tablesObject.table1Rows.size(), 5);
//  	  
//  	  tablesObject.table1();
//  	  
//  	Assert.assertEquals(6, tablesObject.table1ColsCounter);
//  }
	
	@Test (priority = 1)
    public void testTable1() throws InterruptedException {
		homePageObject.openTables();
		
    	WebElement table1 =  driver.findElement(By.id("table1"));
    	List<WebElement> tableRows = table1.findElements(By.tagName("tr"));
    	
    	Assert.assertEquals(tableRows.size(), 5);
    	
    	int counter = 0;
    	int colsCounter = 0;
    	
    	for(WebElement row : tableRows) {
    		if(counter == 0) {
        		List<WebElement> cells = row.findElements(By.tagName("th"));
        		for(WebElement cell : cells) {
        			colsCounter++;
        		}
        		System.out.println();
    		}
    		else {
    			List<WebElement> cells = row.findElements(By.tagName("td"));
        		
        		for(WebElement cell : cells) {
        			System.out.print(cell.getText()+"    ");
        		}
        		System.out.println();
    		}
    		counter++;
    	}
    	Assert.assertEquals(6, colsCounter);
    }
	
	@Test (priority = 2)
    public void testTable2() {
		
    	WebElement table2 =  driver.findElement(By.id("table2"));
    	List<WebElement> tableRows = table2.findElements(By.tagName("tr"));
    	
    	Assert.assertEquals(tableRows.size(), 5);
    	
    	int counter = 0;
    	int colsCounter = 0;
    	
    	for(WebElement row : tableRows) {
    		if(counter == 0) {
        		List<WebElement> cells = row.findElements(By.tagName("th"));
        		for(WebElement cell : cells) {
        			colsCounter++;
        		}
        		System.out.println();
    		}
    		else {
    			List<WebElement> cells = row.findElements(By.tagName("td"));
        		
        		for(WebElement cell : cells) {
        			System.out.print(cell.getText()+"\t");
        		}
        		System.out.println();
    		}
    		counter++;
    	}
    	Assert.assertEquals(6, colsCounter);
    }
}
