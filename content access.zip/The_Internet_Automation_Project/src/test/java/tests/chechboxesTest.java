package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.Checkboxes;
import pages.HomePage;

public class chechboxesTest extends TestBase {

	HomePage HomePageObject = new HomePage(driver);
	Checkboxes checkboxesObject = new Checkboxes(driver);
	
	@Test
	public void TestCheckboxes() {
		HomePageObject.openCheckboxes();
		Assert.assertTrue(checkboxesObject.checkbox1.isEnabled());
		Assert.assertTrue(checkboxesObject.checkbox2.isEnabled());
		checkboxesObject.EnableCheckboxes();
		
		Assert.assertTrue(checkboxesObject.checkbox1.isDisplayed());
		Assert.assertTrue(checkboxesObject.checkbox2.isDisplayed());
		Assert.assertTrue(checkboxesObject.checkbox1.isSelected());
		Assert.assertTrue(checkboxesObject.checkbox2.isSelected());
		
		checkboxesObject.DisableCheckboxes();
		Assert.assertTrue(checkboxesObject.checkbox1.isDisplayed());
		Assert.assertTrue(checkboxesObject.checkbox2.isDisplayed());
		Assert.assertTrue(!checkboxesObject.checkbox1.isSelected());
		Assert.assertTrue(!checkboxesObject.checkbox2.isSelected());

	}
}
