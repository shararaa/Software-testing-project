package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.FormAuthentication;
import pages.HomePage;

public class LoginTest extends TestBase {
	
	HomePage HomePageOpject = new HomePage(driver);
	FormAuthentication FormAuthenticationObject = new FormAuthentication(driver);
	
	@Test(priority = 1)
	public void testLogin_positive() {
		HomePageOpject.openFormAuthentication();
		FormAuthenticationObject.userCanLogin();
		
		Assert.assertTrue(FormAuthenticationObject.statusMessage.getText()
				.contains("You logged into a secure area!"));
		
		FormAuthenticationObject.logoutBTN.click();
	}
	
  @Test(priority = 2)
  public void testWrongPassword() throws InterruptedException {
	  FormAuthenticationObject.wrongPassword();
	  
	  Assert.assertTrue(FormAuthenticationObject.statusMessage.getText().contains("Your password is invalid!"));
  }
  
  @Test(priority = 3)
  public void testWrongUsername() throws InterruptedException {
	  FormAuthenticationObject.wrongUsername();
	  
	  Assert.assertTrue(FormAuthenticationObject.statusMessage.getText().contains("Your username is invalid!"));
  }
  
  @Test(priority = 4)
  public void testEmptyUsername() throws InterruptedException {
	  FormAuthenticationObject.emptyUsername();
	  
	  Assert.assertTrue(FormAuthenticationObject.statusMessage.getText().contains("Username is empty !"));
  }
  
  @Test (priority = 5)
  public void testEmptyPassword() throws InterruptedException {
	  FormAuthenticationObject.emptyUsername();
	  
	  Assert.assertTrue(FormAuthenticationObject.statusMessage.getText().contains("Password is empty !"));
  }
  
  @Test (priority = 6)
  public void testEmptyUsernameAndPassword() throws InterruptedException {
	  FormAuthenticationObject.emptyUsername();
	  
	  Assert.assertTrue(FormAuthenticationObject.statusMessage.getText().contains("Please fill the planks!"));
  }
}
