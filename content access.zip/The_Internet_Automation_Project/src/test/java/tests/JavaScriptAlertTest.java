package tests;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.JavaScriptAlerts;

public class JavaScriptAlertTest extends TestBase {
  
	HomePage homePageObject = new HomePage(driver);
	JavaScriptAlerts JavaScriptAlertsObject = new JavaScriptAlerts(driver);
	
	@Test (priority = 1)
	public void simpleAlertTest () {
		homePageObject.openAlerts();
		JavaScriptAlertsObject.simpleAlert();
		Alert alert = driver.switchTo().alert();
		
		Assert.assertEquals(alert.getText(), "I am a JS Alert");
		alert.accept();
		
		Assert.assertEquals(JavaScriptAlertsObject.result.getText(), "You successfully clicked an alert");
	}
	
	@Test (priority = 2)
	public void confirmAlertTest () {
		JavaScriptAlertsObject.confirmAlert();
		Alert alert = driver.switchTo().alert();
		
		Assert.assertEquals(alert.getText(), "I am a JS Confirm");
		  alert.accept();
		
		Assert.assertEquals(JavaScriptAlertsObject.result.getText(), "You clicked: Ok");
		
		JavaScriptAlertsObject.confirmAlert();
		alert.dismiss();
		
		Assert.assertEquals(JavaScriptAlertsObject.result.getText(), "You clicked: Cancel");
	}
	
	@Test (priority = 3)
	public void promptAlert() {
		JavaScriptAlertsObject.promptAlert();
		Alert alert = driver.switchTo().alert();
		
		Assert.assertEquals(alert.getText(), "I am a JS prompt");
		
		alert.sendKeys("Hi");
		alert.accept();
		
		Assert.assertEquals(JavaScriptAlertsObject.result.getText(),"You entered: Hi");
	}
}
