package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.NestedFrames;

public class NestedFramesTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
	NestedFrames nestedFramesObject = new NestedFrames(driver);
	
  @Test (priority = 1)
  public void bottomFrameTest() {
	  homePageObject.openNestedFrames();
	  nestedFramesObject.bottomFrame();
	  
	  WebElement body = driver.findElement(By.tagName("body"));
	  Assert.assertTrue(body.getText().contains("BOTTOM"));
	  driver.switchTo().defaultContent();
  }
  
  @Test (priority = 2)
  public void leftFrameTest() {
	  nestedFramesObject.leftFrame();
	  
	  WebElement body = driver.findElement(By.tagName("body"));
	  Assert.assertTrue(body.getText().contains("LEFT"));
	  driver.switchTo().parentFrame();
  }
  
  @Test (priority = 3)
  public void middleFrameTest() {
	  nestedFramesObject.middleFrame();
	  
	  WebElement body = driver.findElement(By.tagName("body"));
	  Assert.assertTrue(body.getText().contains("MIDDLE"));
	  driver.switchTo().parentFrame();
  }
  
  @Test (priority = 4)
  public void rightFrameTest() {
	  nestedFramesObject.rightFrame();
	  
	  WebElement body = driver.findElement(By.tagName("body"));
	  Assert.assertTrue(body.getText().contains("RIGHT"));
	  driver.switchTo().parentFrame();
  }
}
