package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.MultipleWindows;

public class WindowsTest extends TestBase {
	
	HomePage homePageObject = new HomePage(driver);
	MultipleWindows multipleWindowsObject = new MultipleWindows(driver);
	
  @Test
  public void testMultipleWindwos() {
	  
	  homePageObject.openMultipleWindows();
	  multipleWindowsObject.windows();
	  
	  String currentWindowId = driver.getWindowHandle();
	  
	  for (String windowId : driver.getWindowHandles()) {
			String title = driver.switchTo().window(windowId).getTitle();
			if(title.equalsIgnoreCase("New Window")) {
				WebElement heading = driver.findElement(By.xpath("/html/body/div/h3"));
				Assert.assertEquals(heading.getText(), "New Window");
				driver.close();
				break;
			}
			driver.switchTo().window(currentWindowId);
			WebElement heading = driver.findElement(By.tagName("h3"));
			Assert.assertEquals(heading.getText(), "Opening a new window");
	  }
  }
}
