package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class DragAndDrop extends pageBase{

	public DragAndDrop(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id = "column-a")
	public WebElement source;
	
	@FindBy(id = "column-b")
	public WebElement destination;
	
	public void switchPlaces (){
		
		Actions builder = new Actions(driver);
		builder.dragAndDrop(source, destination).build().perform();
	}

}
