package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FileUpload extends HomePage {

	public FileUpload(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "file-upload")
	WebElement inputField;
	
	@FindBy(id ="file-submit")
	WebElement uploadButton;
	
	@FindBy(xpath = "//*[@id=\"content\"]/div/h3")
	WebElement resultMessage;
	 
	 public void uploadFile(String filePath){
	        inputField.sendKeys(filePath);
	        uploadButton.click();
	    }
	 public boolean isUploaded() {
		return resultMessage.isDisplayed();
	 }
}
