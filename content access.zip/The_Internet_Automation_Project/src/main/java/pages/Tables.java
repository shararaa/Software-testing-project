package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tables extends pageBase {

	public Tables(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id = "table1")
	WebElement table1;
	
	@FindBy(id = "table2")
	WebElement table2;
	
	public List<WebElement> table1Rows = table1.findElements(By.tagName("tr"));
	public List<WebElement> table2Rows = table2.findElements(By.tagName("tr"));
	
	public int table1Counter = 0 , table1ColsCounter = 0;
	public int table2Counter = 0 , table2ColsCounter = 0;
	
	public void table1() {
		for(WebElement row : table1Rows) {
    		if(table1Counter == 0) {
        		List<WebElement> cells = row.findElements(By.tagName("th"));
        		for(WebElement cell : cells) {
        			table1ColsCounter++;
        		}
        		System.out.println();
    		}
    		else {
    			List<WebElement> cells = row.findElements(By.tagName("td"));
        		
        		for(WebElement cell : cells) {
        			System.out.print(cell.getText()+"    ");
        		}
        		System.out.println();
    		}
    		table1Counter++;
    	}
    }
	
	public void table2() {
		for(WebElement row : table2Rows) {
    		if(table2Counter == 0) {
        		List<WebElement> cells = row.findElements(By.tagName("th"));
        		for(WebElement cell : cells) {
        			table2ColsCounter++;
        		}
        		System.out.println();
    		}
    		else {
    			List<WebElement> cells = row.findElements(By.tagName("td"));
        		
        		for(WebElement cell : cells) {
        			System.out.print(cell.getText()+"    ");
        		}
        		System.out.println();
    		}
    		table2Counter++;
    	}
    }

}
