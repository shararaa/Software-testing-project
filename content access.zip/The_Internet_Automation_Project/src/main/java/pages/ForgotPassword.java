package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ForgotPassword extends pageBase {

	public ForgotPassword(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "email")
	WebElement emailTXT;
	
	@FindBy(xpath = "//*[@id=\"form_submit\"]")
	WebElement retrievePasswordBTN;
	
	public void validEmail() {
		emailTXT.sendKeys("mohamedsharara@gmail.com");
		retrievePasswordBTN.click();
	}
	
	public void nonValidEmail() {
		emailTXT.sendKeys("marco reus");
		retrievePasswordBTN.click();
	}
}
