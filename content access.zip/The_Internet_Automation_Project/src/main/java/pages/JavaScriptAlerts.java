package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JavaScriptAlerts extends pageBase {

	public JavaScriptAlerts(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//*[@id=\"content\"]/div/ul/li[1]/button")
	WebElement simpleAlertBTN;
	
	@FindBy(xpath = "//*[@id=\"content\"]/div/ul/li[2]/button")
	WebElement confirmAlertBTN;
	
	@FindBy (xpath = "//*[@id=\"content\"]/div/ul/li[3]/button")
	WebElement promptAlertBTN;
	
	@FindBy(id = "result")
	public WebElement result;
	
	public void simpleAlert() {
		simpleAlertBTN.click();
	}
	
	public void confirmAlert() {
		confirmAlertBTN.click();
	}
	
	public void promptAlert() {
		promptAlertBTN.click();
	}
}
