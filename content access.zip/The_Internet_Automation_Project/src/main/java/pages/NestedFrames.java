package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class NestedFrames extends pageBase {

	public NestedFrames(WebDriver driver) {
		super(driver);
	}

	String bottomFrame = "frame-bottom";
	String topFrame = "frame-top";
	String leftFrame = "frame-left";
	String rightFrame = "frame-right";
	String middleFrame = "frame-middle";
	
	public void bottomFrame() {
		  driver.switchTo().frame(bottomFrame);
	}
	
	 public void leftFrame() {
		  driver.switchTo().frame(topFrame);
		  driver.switchTo().frame(leftFrame);
	 }
	 
	 public void rightFrame() {
		  driver.switchTo().frame(rightFrame);
	 }
	 
	 public void middleFrame() {
		  driver.switchTo().frame(middleFrame);
	 }
}
