package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends pageBase {

	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(linkText = "Drag and Drop")
	WebElement dragAndDrop;
	
	@FindBy(linkText = "Dropdown")
	WebElement dropDown;
	
	@FindBy(linkText = "Checkboxes")
	WebElement checkboxes;
	
	@FindBy(linkText = "Form Authentication")
	WebElement formAuthentication;
	
	@FindBy(linkText = "Forgot Password")
	WebElement forgotPassword;
	
	@FindBy(linkText = "Multiple Windows")
	WebElement multipleWindows;
	
	@FindBy(linkText = "Nested Frames")
	WebElement nestedFrames;
	
	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[29]/a")
	WebElement javaScriptAlerts;
	
	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[41]/a")
	WebElement tables;
	
	@FindBy(linkText = "File Download")
	WebElement filedDownload;
	
	@FindBy(linkText = "File Upload")
	WebElement filedUpload;
	
	public void openFormAuthentication () {
		formAuthentication.click();
	}
	public void openCheckboxes () {
		checkboxes.click();
	}
	public void openAlerts () {
		javaScriptAlerts.click();
	}
	public void openDragAndDrop() {
		dragAndDrop.click();
	}
	public void openMultipleWindows() {
		multipleWindows.click();
	}
	public void openDropdownList() {
		dropDown.click();
	}
	public void openNestedFrames() {
		nestedFrames.click();
	}
	public void openForgotPassword() {
		forgotPassword.click();
	}
	public void openTables() {
		tables.click();
	}
	public void openFileDownload() {
		filedDownload.click();
	}
	public void openFileUpload() {
		filedUpload.click();
	}
}
