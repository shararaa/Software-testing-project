package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Checkboxes extends pageBase {
	public Checkboxes(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath = "/html/body/div[2]/div/div/form/input[1]")
	public WebElement checkbox1;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/form/input[2]")
	public WebElement checkbox2;
	
	public void EnableCheckboxes () {
		
		  if(!checkbox1.isSelected())
			  checkbox1.click();
		  
		  if(!checkbox2.isSelected())
			  checkbox2.click();
			  
		}
	public void DisableCheckboxes () {
		
		  if(checkbox1.isSelected())
			  checkbox1.click();
		  
		  if(checkbox2.isSelected())
			  checkbox2.click();
			  
		}

}
