package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FormAuthentication extends pageBase {

	public FormAuthentication(WebDriver driver) {
		super(driver);
	}
	@FindBy(id = "username")
	WebElement usernameTXT;
	
	@FindBy(id = "password")
	WebElement passwordTXT;

	@FindBy(className = "radius")
	WebElement loginBTN;
	
	@FindBy(id = "flash")
	public WebElement statusMessage;
	
	@FindBy(linkText = "Logout")
	public WebElement logoutBTN;
	
	public String username = "tomsmith", password ="SuperSecretPassword!";
	
	public void userCanLogin() {
		usernameTXT.sendKeys(username);
		passwordTXT.sendKeys(password);
		loginBTN.click();
	}
	
	public void wrongPassword() {
		usernameTXT.clear();
		passwordTXT.clear();
		usernameTXT.sendKeys(username);
		   passwordTXT.sendKeys(password.substring(0, password.length() -1));
		   loginBTN.click();
	}
	
	public void wrongUsername() {
		usernameTXT.clear();
		passwordTXT.clear();
		usernameTXT.sendKeys(username.substring(0, username.length() - 1));
		passwordTXT.sendKeys(password);
		loginBTN.click();
	}
	
	public void emptyUsername() {
		usernameTXT.clear();
		passwordTXT.clear();
	   passwordTXT.sendKeys(password);
	   loginBTN.click();
	}
	
	public void emptyPassword() {
		usernameTXT.clear();
		passwordTXT.clear();
		usernameTXT.sendKeys(username);
		loginBTN.click();
	}
	
	public void emptyUsernameAndPassword() {
		usernameTXT.clear();
		passwordTXT.clear();
		loginBTN.click();
	}
	
}
